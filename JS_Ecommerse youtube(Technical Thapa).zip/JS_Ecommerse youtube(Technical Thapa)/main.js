import './style.css'

import product from "./api/product.json";

import { showProductContainer } from './homeProductCards';

// Define a fun name 'showProductContainer' that takes an array of product as input...

showProductContainer(product);